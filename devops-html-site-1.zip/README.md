# DevOps HTML Project

This is a simple static website created for practicing DevOps deployment workflows.

## What's Included:
- Static HTML/CSS site
- Dockerfile to containerize the site
- Ready for GitHub Pages deployment

## Author:
Suriyakumar S
